<?php
/* * * * * * * * * * * * * * *
 * Returns all published posts
 * * * * * * * * * * * * * * */
function getPublishedPosts()
{
    // use global $conn object in function
    global $conn;
    $sql = 'SELECT * FROM posts order by created_at desc';
    $result = mysqli_query($conn, $sql);

    $posts = [];

    // fetch all posts as an associative array called $posts
    while ($row = mysqli_fetch_assoc($result)) {
        $posts[] = $row;
    }

    return $posts;
}

function updateViews($slug)
{
    global $conn;

    $sql = "UPDATE posts SET views = views + 1 WHERE slug = '$slug'";
    $result = mysqli_query($conn, $sql);

    print_r(mysqli_error($conn));

    return $result;
}

function time_elapsed_string($datetime, $full = false)
{
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = [
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    ];
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) {
        $string = array_slice($string, 0, 1);
    }
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

/* * * * * * * * * * * * * * *
 * Returns a single post
 * * * * * * * * * * * * * * */
function getPost($slug)
{
    global $conn;
    // Get single post slug
    $post_slug = $_GET['post-slug'];
    $sql = "SELECT * FROM posts WHERE slug='$post_slug'";
    $result = mysqli_query($conn, $sql);

    // fetch query results as associative array.
    $post = mysqli_fetch_assoc($result);

    return $post;
}
?>