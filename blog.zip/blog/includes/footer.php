<style>
  .sl_button {
      border: 2px solid #f77e0b;
      border-radius: 29px;
      width: 13vw;
      min-height: 35px;
      height: 5vh;
      background-color: #f77e0b;
      margin-top: 30px;
      font-size: 12px;
      font-weight: bold;
      color: #ffffff;
      outline: 0;
    }  


	@media screen and (max-width: 1080px) {
		.row .useful-links {
			transform: translateX(0) !important;
		}
		
		#footer .fab {
		    font-size: 2rem;
		}
	}
	
	.footer a {
	    font-weight: bolder;
	    color: #8181b9;
	}
	
	.footer a:hover {
	    text-decoration: underline;
	}
	
	
    
</style>


<div class="footer" style="background-color: rgb(21, 21, 47); width: 100%; text-align: left; font-family: Playfair; padding: 3rem 0; color: white">
<div class="container">
    <div class="row">
	<div class="col-lg-3 mb-4 pe-2 mt-3">
		<img src="https://startoonlabs.com/img/mainlogo_onscroll.png" class="img-responsive" width="80%" />
		<br />
		<p style="padding-right: 1rem; color: #8181b9" class="my-4">
			Startoon Labs is a medtech company providing innovative solutions to revolutionize the healthcare industry. A competent team including alumni from IIT & IIM striving to address the gaps in the healthcare ecosystem.
		</p>
		<img src="https://www.positivessl.com/images/seals/positivessl_trust_seal_lg_222x54.png" style="margin-top: 2rem; height: 4rem"/>
	</div>
	<div class="col-lg-3 useful-links mt-3">
		<p class="footer_header" style="font-size: 1.5rem; font-weight: bold"> Useful Links</p>
		<a href="index.php" class="text-decoration-none"> Home </a> <br />
		<a href="about.php" class="text-decoration-none"> About Us </a> <br />
		<a href="product.php" class="text-decoration-none"> Products </a> <br />

		 <a href="careers.php" class="text-decoration-none"> Careers </a> <br /> 
		<a href="rentalAgreement.php" target="_blank" class="text-decoration-none">Rental Agreement</a><br>
		<a href="policy.php" class="text-decoration-none" target="_blank"> Privacy Policy </a> <br />
		<a href="refundPolicy.php" class="text-decoration-none" target="_blank"> Refund Policy </a> <br />
		<a href="termsOfUse.php" class="text-decoration-none" target="_blank"> Terms of Use </a> <br />
		<a href="#" class="text-decoration-none" data-toggle="modal" data-target="#newsletter">Newsletter</a><br>
	</div>
	<div class="col-lg-3"> 
		<p class="footer_header mt-3" style="font-size: 1.5rem; font-weight: bold;"> Sales</p>
		<p> <i class="fas fa-envelope"></i> &nbsp; sales@startoonlabs.com </p>
		<p class="footer_header mt-3" style="font-size: 1.5rem; font-weight: bold"> Careers</p>
		<p> <i class="fas fa-envelope"></i> &nbsp; careers@startoonlabs.com </p>
	</div>
	<div class="col-lg-3">
		<p class="footer_header mt-3" style="font-size: 1.5rem; font-weight: bold"> Contact </p>
		<p> <i class="fas fa-phone-alt"></i> &nbsp; +91 879 089 6481 <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; +91 913 392 5836 </p>
		<i class="fas fa-envelope"></i>&nbsp;&nbsp; contactus@startoonlabs.com</p>
		<!--<button class="sl_button">SEND A MESSAGE</button> -->
		<button class="sl_button" data-toggle="modal" data-target="#contact_form"> SEND A MESSAGE </button><br /><br />
		<p class='social_icons'> Follow Us:
			<a href="https://www.facebook.com/startoonlabs/" target="_blank"><i class="fab fa-facebook-square"></i> </a>&nbsp;
			<a href="https://in.linkedin.com/company/startoonlabs" target="_blank"><span class="fab fa-linkedin"></span> </a>&nbsp;
			<a href="https://twitter.com/startoonlabs" target="_blank"><span class="fab fa-twitter-square"></span> </a>&nbsp;
			<a href="https://www.instagram.com/startoonlabs/" target="_blank" style="color: black"><span class="fab fa-instagram-square"></span></a>
		</p>
	</div>
	</div></div></div>
	
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
</body>

</html>