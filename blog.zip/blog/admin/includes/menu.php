<div class="menu">
    <div class="card">
        <div class="card-header">
            <h2>Actions</h2>
        </div>
        <div class="card-content">
            <a href="<?php echo 'create_post.php'; ?>">Create Posts</a>
            <a href="<?php echo 'posts.php'; ?>">Manage Posts</a>
        </div>
    </div>
</div>