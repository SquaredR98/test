<?php include('config.php'); ?>
<?php include('includes/public_functions.php'); ?>
<?php include('includes/head_section.php'); ?>
<?php 
	// Get posts under a particular topic
	if (isset($_GET['topic'])) {
		$topic_id = $_GET['topic'];
		$posts = getPublishedPostsByTopic($topic_id);
	}
?>
	<title>LifeBlog | Home </title>
</head>
<body>
<!-- Navbar -->
	<?php include( ROOT_PATH . '/includes/navbar.php'); ?>
<!-- // Navbar -->
<!-- content -->
<div class="container">
<div class="content">
	<h2 class="content-title mt-3">
		Articles on <?php echo getTopicNameById($topic_id); ?>
	</h2>
	<hr>
	<?php foreach ($posts as $post): ?>
		<div class="individual-post card my-3">
        	<div class="row g-0" style="margin-left: 0px;">
        	    <div class="col-lg-5">
        		<img src="<?php echo BASE_URL . 'static/images/' . $post['image']; ?>" class="img-fluid rounded-start" alt="" style="height: 100%">
        		</div>
        		<div class="col-lg-7 home-page-post-content px-4" style="display:flex; flex-direction: column; justify-content: space-between;">
        		    <div class="">
            		    <div class="subtext-header-post my-3" style="display:flex; justify-content: space-between; align-items: center">
            			    <div style="display:flex; align-items: center; font-size: 1rem">
                		        <span class="badge rounded-pill bg-primary name-pill me-3" style="display:flex; justify-content: center; align-items: center ; font-size: 1rem"><?php echo substr($post['author'], 0, 1) ?>
                		        </span>
                		        <span>
                		            <p><?php echo $post['author'] ?></p>
                		            <?php echo time_elapsed_string($post["created_at"]) ?>
                		            
                		        </span>
            		        </div>
            		        <i class="fas fa-ellipsis-v"></i>
            		    </div>
                		<a href="single_post.php?post-slug=<?php echo $post['slug']; ?>" class="post-link">
                			<div class="post_info">
                				<h4 class="post-title"><?php echo $post['title'] ?></h4>
                				<div class="info">
                					<?php echo  html_entity_decode(substr($post['body'], 0, 250)) ?>...
                				</div>
                			</div>
                		</a>
            		</div>
            		
            		<div class="post-footer py-2 mt-2" style="display: flex; border-top: 1px solid #00000044">
            		    <p class="pe-2">0 views</p>
            		    <p>0 likes</p>
            		</div>
        		</div>
        	</div>
        </div>
	<?php endforeach ?>
<!-- // content -->
</div>
</div>
<!-- // container -->

<!-- Footer -->
	<?php include( ROOT_PATH . '/includes/footer.php'); ?>
<!-- // Footer -->