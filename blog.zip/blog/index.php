<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<!-- The first include should be config.php -->
<?php require_once 'config.php'; ?>

<?php require_once './includes/public_functions.php'; ?>

<!-- Retrieve all posts from database  -->
<?php $posts = getPublishedPosts(); ?>

<?php if (isset($_GET['post-slug'])) {
    $post = getPost($_GET['post-slug']);
} ?>

<?php require_once ROOT_PATH . '/includes/head_section.php'; ?>
<title>Startoon Labs | Blog </title>
</head>


<body>
    <!-- navbar -->
    <?php include ROOT_PATH . '/includes/navbar.php'; ?>
    <!-- // navbar -->

    <!-- // banner -->
    <?php include ROOT_PATH . '/includes/banner.php'; ?>

    <!-- Page content -->
    <div class="container">
        <div class="blog-home-page-head mt-5">
            <h1 class="fw-bold" style="color: #4141a8;">Recent Articles</h1>
            <ul class="nav justify-content-end">

            </ul>
        </div>
        <hr>
        <?php foreach ($posts as $post): ?>
        <div class="blog-home-individual-post mb-5">
            <div class="row g-0" style="margin-left: 0px;">
                <div class="col-lg-5">
                    <a href="single_post.php?post-slug=<?php echo $post[
                        'slug'
                    ]; ?>" class="post-link">
                        <img src="<?php echo BASE_URL .
                            'static/images/' .
                            $post[
                                'image'
                            ]; ?>" class="img-fluid featured-post-image" alt="" style="height: 100%"></a>
                </div>
                <div class="col-lg-7 blog-home-post-content px-4"
                    style="display:flex; flex-direction: column; justify-content: space-between;">
                    <div class="">
                        <div class="subtext-header-post my-3"
                            style="display:flex; justify-content: space-between; align-items: center">
                            <div style="display:flex; align-items: center; font-size: 1rem">
                                <span class="badge rounded-pill bg-primary blog-home-name-pill me-3"
                                    style="display:flex; justify-content: center; align-items: center ; font-size: 1rem"><?php echo substr(
                                        $post['author'],
                                        0,
                                        1
                                    ); ?>
                                </span>
                                <span class="author-and-time">
                                    <small class="fw-bold"><?php echo $post[
                                        'author'
                                    ]; ?></small><br>
                                    <small class="fw-bold"><?php echo time_elapsed_string(
                                        $post['created_at']
                                    ); ?></small>

                                </span>
                            </div>
                            <i class="fas fa-ellipsis-v"></i>
                        </div>
                        <a href="single_post.php?post-slug=<?php echo $post[
                            'slug'
                        ]; ?>" class="post-link">
                            <div class="post_info">
                                <h2 class="blog-home-post-title"><?php echo $post[
                                    'title'
                                ]; ?></h2>
                                <div class="blog-home-post-info">
                                    <?php echo $post['abstract']; ?>...
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="post-footer py-2 mt-2" style="display: flex; border-top: 1px solid #00000044">
                        <small class="pe-2 text-muted">0 views</small>
                        <small class="text-muted">0 likes</small>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    </div>
    </div>

    <!-- footer -->
    <?php include ROOT_PATH . '/includes/footer.php'; ?>
    <!-- // footer -->