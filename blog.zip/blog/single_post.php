<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<?php include 'config.php'; ?>
<?php include 'includes/public_functions.php'; ?>
<?php if (isset($_GET['post-slug'])) {
    $post = getPost($_GET['post-slug']);
} ?>
<?php $posts = getPublishedPosts(); ?>
<?php updateViews($_GET['post-slug']); ?>
<?php include 'includes/head_section.php'; ?>
<title> <?php echo $post['title']; ?> | Blog</title>
</head>

<body>
    <!-- Navbar -->
    <?php include ROOT_PATH . '/includes/navbar.php'; ?>
    <!-- // Navbar -->

    <div class="container">
        <div class="row">
            <div class="col-lg-9">
                <div class="subtext-header-post my-3"
                    style="display:flex; justify-content: space-between; align-items: center">
                    <div style="display:flex; align-items: center; font-size: 1rem">
                        <span class="badge rounded-pill bg-primary single-post-name-pill me-3"
                            style="display:flex; justify-content: center; align-items: center ; font-size: 1rem"><?php echo substr(
                                $post['author'],
                                0,
                                1
                            ); ?>
                        </span>
                        <span class="author-and-time">
                            <small class="fw-bold"><?php echo $post[
                                'author'
                            ]; ?></small><br>
                            <small class="fw-bold"><?php echo time_elapsed_string(
                                $post['created_at']
                            ); ?></small>

                        </span>
                    </div>
                    <i class="fas fa-ellipsis-v"></i>
                </div>

                <div class="full-post-div">
                    <h2 class="single-post-title my-4"><?php echo $post[
                        'title'
                    ]; ?></h2>
                    <blockquote class="fw-bold fst-italic">
                        <p class="single-post-abstract"><?php echo $post[
                            'abstract'
                        ]; ?></p>
                    </blockquote class="blockquote">
                    <img src="<?php echo BASE_URL .
                        'static/images/' .
                        $post[
                            'image'
                        ]; ?>" class="img-fluid mb-3 text-center" alt="">


                    <div class="single-post-body-div">
                        <?php echo html_entity_decode($post['body']); ?>
                    </div>
                </div>
                <hr>
                <nav class="nav share-links">
                    <a class="nav-link"><i class="fab fa-facebook-f"></i></a>
                    <a class="nav-link"><i class="fab fa-twitter"></i></a>
                    <a class="nav-link"><i class="fab fa-linkedin-in"></i></a>
                    <a class="nav-link"><i class="fas fa-link"></i></a>
                </nav>

                <hr>
            </div>
            <div class="col-lg-3">
                <ul class="nav justify-content-start mt-4">
                    <?php print_r(explode(',', $post['keywords'])); ?>

                </ul>
            </div>

        </div>



        <div class="recent-article-single-post mt-4"
            style="display: flex; justify-content: space-between; align-items: center">
            <h4 class="my-3 fw-bold">Recent Articles</h4>
            <a href="">See All</a>
        </div>
        <div class="row mb-5">
            <?php foreach (array_slice($posts, 0, 3) as $post): ?>
            <div class="col-lg-4">
                <a href="single_post.php?post-slug=<?php echo $post[
                    'slug'
                ]; ?>" class="post-link">
                    <div class="my-3">
                        <img src="<?php echo BASE_URL .
                            'static/images/' .
                            $post[
                                'image'
                            ]; ?>" class="img-fluid" alt="..." style="height: 250px">
                        <div class="card-body">
                            <div class="post_info">
                                <h4 class="recent-article-single-post-title"><?php echo $post[
                                    'title'
                                ]; ?></h4>
                            </div>

                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <!-- // content -->

    <?php include ROOT_PATH . '/includes/footer.php'; ?>